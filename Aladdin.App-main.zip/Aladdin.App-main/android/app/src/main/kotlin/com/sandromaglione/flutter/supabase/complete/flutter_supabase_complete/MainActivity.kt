package com.sandromaglione.flutter.supabase.complete.flutter_supabase_complete

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
