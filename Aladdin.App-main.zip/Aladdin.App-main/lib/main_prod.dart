import 'package:flutter_supabase_complete/main_common.dart';

/// Perform extra configuration required for production environment
Future<void> main() async {
  await mainCommon();
}
